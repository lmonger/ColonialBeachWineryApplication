package com.example.colonialbeachwineryapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ItemListAdapter extends ArrayAdapter<Item> {

    private static List<Item> items;
    public ItemListAdapter(@NonNull Context context, int resource, @NonNull List<Item> items) {
        super(context, resource, items);
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView ==null){
         convertView = LayoutInflater.from(getContext()).inflate(R.layout.single_menu_item, parent, false);
        }
        Item item = items.get(position);
        TextView itemName = convertView.findViewById(R.id.txtItemName);
        itemName.setText(item.getName());

        TextView itemPrice = convertView.findViewById(R.id.txtItemPrice);
        itemPrice.setText(DataHelper.getPriceFormat(item.getPrice()));

        ImageView imgView = convertView.findViewById(R.id.imgItem);

        Bitmap bitmap = DataHelper.getBitmapAsset(getContext(),item.getId());
        imgView.setImageBitmap(bitmap);

        return convertView;
    }
}
