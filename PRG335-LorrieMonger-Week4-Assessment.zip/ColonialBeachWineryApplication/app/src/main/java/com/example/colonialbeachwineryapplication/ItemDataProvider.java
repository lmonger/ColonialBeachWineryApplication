package com.example.colonialbeachwineryapplication;

import android.icu.text.StringSearch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ItemDataProvider {
    public static List<Item> items = new ArrayList<>();
    public static Map<String, Item> itemMap = new HashMap<>();

    public static void addItem(Item item) {
        items.add(item);
        itemMap.put(item.getId(), item);
    }

    public static  List<String> getItemNames(){
        List<String> list = new ArrayList<>();
        for(Item item :items){
            list.add(item.getName());
    }
        return list;
    }

    public static List<Item> getFilteredList(String search){
        List<Item> filterList = new ArrayList<>();
        for(Item item : items){
            if(item.getId().contains(search)) {
                filterList.add(item);
            }
        }
        return filterList;
    }
    static {
        addItem(new Item("ANNALISA MOSCATO","750ML\n" +
                "Piedmont, Italy- A fresh, easy-drinking white with aromas of peach blossoms and citrus wrapped around a softly sweet, luscious palate filled with nectarine and apple notes. Ideal with dessert or fresh fruit.\n" +
                "\nBRAND" +
                "Annalisa" +
                "\nCOUNTRY / STATE" +
                "Italy" +
                "\nREGION" +
                "Piedmont" +
                "\nAPPELLATION" +
                "Asti" +
                "\nWINE TYPE" +
                "Champagne & Sparkling Wine" +
                "\nVARIETAL" +
                "Muscat/Moscato" +
                "\nSTYLE" +
                "Semi-sweet" +
                "TASTE" +
                "Peach, Apple" +
                "\nBODY"+"Medium-bodied","annalisa",9.99));
        addItem(new Item("19 CRIMES THE SENTENCED CABERNET SAUVGNON","750ML\n" +
                "Australia - This wine takes charge with intense lifted aromas of vanilla balanced by a bouquet of red currant, violet and mulberry fruit. Firm and full on the palate with flavors of red currants, dark cherries, and chocolate. Nice lingering finish.\n" +
                "\n" +
                "BRAND\n" +
                "19 Crimes\n" +
                "COUNTRY / STATE\n" +
                "Australia\n" +
                "WINE TYPE\n" +
                "Red Wine\n" +
                "VARIETAL\n" +
                "Cabernet Sauvignon\n" +
                "STYLE\n" +
                "Elegant\n" +
                "TASTE\n" +
                "Red Currant, Chocolate, Berry\n" +
                "BODY\n" +
                "Full-bodied","crimes",14.99));
        addItem(new Item("ROBERT MONDAVI PRIVATE SELECTION CHARDONNAY WHITE WINE","750ML\n" +
                "California- The nose reveals ripe apple, melon, citrus and tropical fruit aromas enriched by creamy malolactic tones, spicy French oak nuances and enticing baked bread scents.\n" +
                "\n" +
                "BRAND\n" +
                "Robert Mondavi Private Selection\n" +
                "COUNTRY / STATE\n" +
                "California\n" +
                "WINE TYPE\n" +
                "White Wine\n" +
                "VARIETAL\n" +
                "Chardonnay\n" +
                "STYLE\n" +
                "Elegant\n" +
                "TASTE\n" +
                "Apple, Melon\n" +
                "BODY\n" +
                "Medium-bodied","mondavi",12.99));
        addItem(new Item("\n" +
                "HOGUE LATE HARVEST RIESLING","750ML\n" +
                "Washington- A medium-bodied, sweet, mouthwatering white wine with notes of tangerine, honey, honeysuckle and a hint of minerality. Zesty aromas of orange, lemon-lime, and peach are followed by flavors of tangerine, apricot, and a trace of mineral. Pairs well with cheesecake or pears.\n" +
                "\n" +
                "BRAND\n" +
                "Hogue\n" +
                "COUNTRY / STATE\n" +
                "Washington\n" +
                "WINE TYPE\n" +
                "White Wine\n" +
                "VARIETAL\n" +
                "Riesling","reisling",11.99));
        addItem(new Item("WINTERTRAUM GLUHWEIN","1L\n" +
                "Germany- A type of mulled wine which is still produced according to Old World tradition. A delicious combination of red wine that is sweetened and spiced with cloves, cinnamon, orange and lemon peel. Gluhwein is ready to drink; heat (do not boil) to enjoy. Great on any cold day.\n" +
                "\n" +
                "BRAND\n" +
                "Wintertraum\n" +
                "COUNTRY / STATE\n" +
                "Germany\n" +
                "WINE TYPE\n" +
                "Dessert & Fortified Wine\n" +
                "VARIETAL\n" +
                "Spiced Wine\n" +
                "STYLE\n" +
                "Very Sweet\n" +
                "TASTE\n" +
                "Citrus, Black Currant\n" +
                "BODY\n" +
                "Full-bodied","gluhwein",7.99));
        addItem(new Item("Bera Brachetto Piemonte","A unique wine, cherry red in color, with a characteristic fragrance of fresh flowers and roses along with a slight musky sensation and intenseness of red fruits. Sweet, vivid, fresh with pleasant acidity, it explodes on the finish with the same fruity notes felt by the nose, that suggest a good pairing with wild berries, sweets and strawberry parfait, jam tarts and sweets in general.\n" +
                "Item ID: #26335\n" +
                "Winery: Bera\n" +
                "Category: Italian Red\n" +
                "Size: 750mL (wine)\n" +
                "Closure: Cork","brachetto",19.99));
    }
}
